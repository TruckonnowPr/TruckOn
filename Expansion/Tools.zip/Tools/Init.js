
if (location.href.includes("centraldispatch.com")) {
    Init();
}